# XuperTV Roku — paquete para prueba

Este canal Roku inicia intentando cargar el catálogo como visitante; el inicio de sesión queda como opción de cuenta. También incluye consulta de secciones y un reproductor Roku para URLs directas compatibles. Las credenciales se introducen en la TV y no se guardan en disco.

## Importante

La única referencia disponible es una APK modificada cuyo paquete es `com.android.mgstxNF`. La página de XuperTV consultada identifica su app oficial con otro paquete (`com.xuper.tvapp`). Este canal de prueba intenta iniciar sesión contra `fuxok.nguvmqhpk.com` y `mptec.dhkrxuzcy.com`, dominios extraídos de la APK y no verificados como servidores oficiales. Al iniciar sesión, la contraseña va en una solicitud HTTPS a esos hosts. Prueba solo con tu autorización y no reutilices una contraseña importante si no confirmaste antes el destino.

El login envía un identificador propio de Roku y declara el cliente como XuperTV-Roku; no suplanta un dispositivo Android. El código `portal200001` corresponde en los recursos de la APK a «Esa versión está fuera de servicio». Este mensaje afecta al intento de login; por sí solo no demuestra que el catálogo de visitante esté bloqueado.

La reproducción de películas y canales depende de lo que entregue el servidor. El reproductor Roku solo puede abrir URLs y formatos compatibles; las respuestas que dependan del reproductor propietario, licencias o protocolo Android no se pueden reproducir automáticamente con esta versión.

## Instalación para prueba

El archivo XuperTV-Roku-test-build.zip es un canal Roku para carga de desarrollo, no una APK de Android. En el Roku se activa el modo desarrollador, se abre el instalador web del Roku desde un navegador de la misma red y se carga el ZIP. Después se abre el canal e inicia sesión con la cuenta.

El modo visitante se intenta con los campos de sesión vacíos. No se pudo confirmar desde el entorno de desarrollo si el servidor acepta esa solicitud; la prueba final requiere abrir el canal en Roku. No compartas la contraseña, el token ni una captura que los contenga.
