sub init()
    m.card = m.top.FindNode("card")
    m.title = m.top.FindNode("title")
    m.description = m.top.FindNode("description")
    renderItem()
    renderFocus()
end sub

sub renderItem()
    content = m.top.itemContent
    if content = invalid then return

    m.title.text = content.title
    m.description.text = content.description
end sub

sub renderFocus()
    if m.top.itemHasFocus
        m.card.color = "0x41415AFF"
    else
        m.card.color = "0x242432FF"
    end if
end sub
