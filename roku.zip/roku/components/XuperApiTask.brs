sub init()
    m.top.functionName = "run"
end sub

sub run()
    m.top.result = ""
    operation = m.top.operation
    if operation = "guestHome"
        doGuestHome()
    else if operation = "login"
        doLogin()
    else if operation = "shelf"
        doShelf()
    else if operation = "play"
        doPlay()
    end if
end sub

sub doGuestHome()
    m.top.status = "Cargando el catálogo como visitante..."
    body = {
        userId: ""
        userToken: ""
        portalCode: ""
        homePageCode: ""
        version: ""
    }
    hosts = ["fuxok.nguvmqhpk.com", "mptec.dhkrxuzcy.com"]
    lastMessage = "El catálogo de visitante no respondió."

    for each host in hosts
        result = postJson(host, "/api/portalCore/getHome", FormatJson(body))
        if result.ok
            parsed = ParseJson(result.body)
            if parsed <> invalid
                returnCode = scalarText(parsed.returnCode)
                if returnCode = "0" and parsed.data <> invalid
                    m.top.sessionHost = host
                    m.top.result = FormatJson({operation: "guestHome", ok: true, homeJson: result.body, host: host})
                    m.top.status = "Catálogo de visitante recibido."
                    return
                end if

                code = scalarText(parsed.returnCode)
                errorMessage = parsed.errorMessage
                if errorMessage <> invalid and errorMessage <> ""
                    lastMessage = errorMessage
                else if code <> ""
                    lastMessage = "El catálogo de visitante fue rechazado (código " + code + ")."
                else
                    lastMessage = "El servicio no devolvió un catálogo de visitante reconocible."
                end if
            else
                lastMessage = "El servicio respondió con un formato que Roku no reconoce."
            end if
        else
            lastMessage = result.message
        end if
    end for

    m.top.result = FormatJson({operation: "guestHome", ok: false, message: lastMessage})
    m.top.status = "No se pudo cargar el catálogo de visitante."
end sub

sub doLogin()
    m.top.status = "Preparando acceso..."
    deviceId = m.top.deviceId
    username = m.top.username
    password = m.top.password

    accountType = "1"
    if Instr(1, username, "@") > 0
        accountType = "2"
    end if
    ' LoginBean in the APK receives this field as the original password string.
    ' postJson sends the JSON only over HTTPS.
    preparedPassword = password
    m.top.password = ""

    body = {
        accountType: accountType
        userName: username
        password: preparedPassword
        type: "1"
        macAddr: deviceId
        areaCode: ""
        verificationCode: ""
        verificationToken: ""
        matadata: ""
        signdata: ""
        channel: "XuperTV-Roku/1.0"
    }

    hosts = ["fuxok.nguvmqhpk.com", "mptec.dhkrxuzcy.com"]
    loginResponse = invalid
    chosenHost = ""
    lastMessage = "No se recibió respuesta del servicio."

    for each host in hosts
        m.top.status = "Conectando con el servicio..."
        result = postJson(host, "/api/portalCore/v8/login", FormatJson(body))
        if result.ok
            parsed = ParseJson(result.body)
            if parsed <> invalid
                if parsed.returnCode <> invalid
                    loginResponse = parsed
                    chosenHost = host
                    exit for
                else if result.body <> invalid and result.body <> ""
                    lastMessage = "El servidor respondió con un formato que la app Roku no reconoce."
                end if
            else if result.body <> invalid and result.body <> ""
                lastMessage = "El servidor respondió con un formato que la app Roku no reconoce."
            end if
        else
            lastMessage = result.message
        end if
    end for

    if loginResponse = invalid
        m.top.result = FormatJson({operation: "login", ok: false, message: lastMessage})
        m.top.status = "No se pudo conectar."
        return
    end if

    returnCode = scalarText(loginResponse.returnCode)
    if returnCode <> "0"
        serverMessage = "El servicio rechazó el acceso (código " + returnCode + ")."
        errorMessage = loginResponse.errorMessage
        if errorMessage <> invalid
            if errorMessage <> ""
                serverMessage = errorMessage
            end if
        end if
        m.top.result = FormatJson({operation: "login", ok: false, message: serverMessage, code: returnCode})
        m.top.status = "Acceso rechazado por el servicio."
        return
    end if

    data = loginResponse.data
    if data = invalid
        m.top.result = FormatJson({operation: "login", ok: false, message: "El servidor aceptó la solicitud, pero no devolvió una sesión utilizable."})
        m.top.status = "Respuesta de sesión incompleta."
        return
    end if
    if data.userId = invalid or data.userToken = invalid
        m.top.result = FormatJson({operation: "login", ok: false, message: "El servidor aceptó la solicitud, pero no devolvió una sesión utilizable."})
        m.top.status = "Respuesta de sesión incompleta."
        return
    end if

    portalCode = ""
    portalCodes = data.portalCodeList
    if Type(portalCodes) = "roArray"
        if portalCodes.Count() > 0
            if portalCodes[0] <> invalid
                if portalCodes[0].portalCode <> invalid
                    portalCode = scalarText(portalCodes[0].portalCode)
                end if
            end if
        end if
    end if
    homeJson = ""
    playlistText = ""
    if portalCode <> ""
        m.top.status = "Acceso correcto. Cargando catálogo..."
        homeBody = {
            userId: data.userId
            userToken: data.userToken
            portalCode: portalCode
            homePageCode: ""
            version: ""
        }
        homeResult = postJson(chosenHost, "/api/portalCore/getHome", FormatJson(homeBody))
        if homeResult.ok
            homeJson = homeResult.body
        end if
    end if

    playlistUrl = data.playlistUrl
    if playlistUrl <> invalid
        if Left(LCase(playlistUrl), 8) = "https://"
            m.top.status = "Revisando el catálogo de la cuenta..."
            playlistText = getText(playlistUrl)
        end if
    end if

    m.top.sessionHost = chosenHost
    session = {
        userId: data.userId
        userToken: data.userToken
        portalCode: portalCode
        host: chosenHost
    }
    resultEnvelope = {
        operation: "login"
        ok: true
        message: "Sesión iniciada."
        session: session
        homeJson: homeJson
        playlistText: playlistText
    }
    m.top.result = FormatJson(resultEnvelope)
    m.top.status = "Sesión iniciada."
end sub

sub doShelf()
    category = ParseJson(m.top.payload)
    if category = invalid
        m.top.result = FormatJson({operation: "shelf", ok: false, message: "No se pudo leer la categoría seleccionada."})
        return
    end if

    columnId = 0
    if category.columnId <> invalid
        columnId = category.columnId
    end if
    columnType = "0"
    if category.type <> invalid and category.type <> ""
        columnType = scalarText(category.type)
    end if

    body = {
        userToken: m.top.userToken
        userId: m.top.userId
        portalCode: m.top.portalCode
        columnId: columnId
        columnType: columnType
        pageSize: 50
        pageNum: 1
        numDisplay: 0
        encryptVersion: 0
    }

    host = getSessionHost()
    result = postJson(host, "/api/portalCore/v3/getShelveData", FormatJson(body))
    if not result.ok
        m.top.result = FormatJson({operation: "shelf", ok: false, message: result.message})
        return
    end if
    parsed = ParseJson(result.body)
    if parsed = invalid
        m.top.result = FormatJson({operation: "shelf", ok: false, message: "La respuesta del catálogo no tiene un formato JSON válido."})
        return
    end if
    m.top.result = FormatJson({operation: "shelf", ok: true, responseJson: result.body})
    m.top.status = "Catálogo recibido."
end sub

sub doPlay()
    item = ParseJson(m.top.payload)
    if item = invalid
        m.top.result = FormatJson({operation: "play", ok: false, message: "No se pudo leer el elemento seleccionado."})
        return
    end if

    host = getSessionHost()
    if item.itemKind = "live"
        body = {
            userToken: m.top.userToken
            userId: m.top.userId
            portalCode: m.top.portalCode
            type: item.columnType
            columnId: item.columnId
            channelCode: item.channelCode
        }
        result = postJson(host, "/api/portalCore/v4/startPlayLive", FormatJson(body))
    else
        body = {
            userToken: m.top.userToken
            userId: m.top.userId
            portalCode: m.top.portalCode
            columnId: item.columnId
            contentId: item.contentId
            seriesContentId: ""
            type: item.columnType
            startTime: 0
            authType: ""
            episodeNumberList: []
        }
        result = postJson(host, "/api/portalCore/v10/startPlayVOD", FormatJson(body))
    end if

    if not result.ok
        m.top.result = FormatJson({operation: "play", ok: false, message: result.message})
        return
    end if

    parsed = ParseJson(result.body)
    if parsed = invalid
        m.top.result = FormatJson({operation: "play", ok: false, message: "El servicio devolvió una respuesta de reproducción ilegible."})
        return
    end if

    streamUrl = findPlayableUrl(parsed)
    if streamUrl <> ""
        streamFormat = "hls"
        if Instr(1, LCase(streamUrl), ".mp4") > 0
            streamFormat = "mp4"
        else if Instr(1, LCase(streamUrl), ".mpd") > 0
            streamFormat = "dash"
        end if
        m.top.result = FormatJson({operation: "play", ok: true, url: streamUrl, streamFormat: streamFormat})
    else
        m.top.result = FormatJson({operation: "play", ok: false, message: "La sesión funciona, pero el reproductor del servicio no entregó una URL directa compatible con Roku."})
    end if
end sub

function postJson(host as String, path as String, body as String) as Object
    port = CreateObject("roMessagePort")
    transfer = CreateObject("roUrlTransfer")
    transfer.SetMessagePort(port)
    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.InitClientCertificates()
    transfer.SetUrl("https://" + host + path)
    transfer.AddHeader("Accept", "application/json")
    transfer.AddHeader("Content-Type", "application/json;charset=utf-8")
    transfer.RetainBodyOnError(true)
    transfer.SetMinimumTransferRate(1, 10)

    if not transfer.AsyncPostFromString(body)
        return {ok: false, message: "Roku no pudo iniciar la conexión segura."}
    end if

    event = wait(30000, port)
    if event = invalid or Type(event) <> "roUrlEvent"
        transfer.AsyncCancel()
        return {ok: false, message: "El servidor no respondió dentro del tiempo esperado."}
    end if

    responseBody = event.GetString()
    responseCode = event.GetResponseCode()
    if responseBody = invalid
        responseBody = ""
    end if

    if responseCode = 0
        failureReason = event.GetFailureReason()
        if failureReason <> invalid and failureReason <> ""
            return {ok: false, message: "No se pudo conectar: " + failureReason}
        end if
    end if
    if responseCode >= 200 and responseCode < 300 and responseBody <> ""
        return {ok: true, body: responseBody, code: responseCode}
    end if
    if responseBody <> ""
        return {ok: true, body: responseBody, code: responseCode}
    end if
    return {ok: false, message: "El servidor respondió con HTTP " + responseCode.ToStr() + "."}
end function

function getText(url as String) as String
    port = CreateObject("roMessagePort")
    transfer = CreateObject("roUrlTransfer")
    transfer.SetMessagePort(port)
    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.InitClientCertificates()
    transfer.SetUrl(url)
    transfer.RetainBodyOnError(true)
    if not transfer.AsyncGetToString()
        return ""
    end if
    event = wait(20000, port)
    if event = invalid or Type(event) <> "roUrlEvent"
        transfer.AsyncCancel()
        return ""
    end if
    body = event.GetString()
    if body = invalid
        return ""
    end if
    return body
end function

function getSessionHost() as String
    if m.top.sessionHost <> invalid and m.top.sessionHost <> ""
        return m.top.sessionHost
    end if
    return "fuxok.nguvmqhpk.com"
end function

function findPlayableUrl(value as Dynamic) as String
    if Type(value) = "roArray"
        for each child in value
            found = findPlayableUrl(child)
            if found <> "" then return found
        end for
    else if Type(value) = "roAssociativeArray"
        for each key in value
            child = value[key]
            if Type(child) = "String"
                keyLower = LCase(key)
                if keyLower = "url" or keyLower = "playurl" or keyLower = "streamurl" or keyLower = "redirect_url" or keyLower = "playcode"
                    if isDirectStream(child) then return child
                end if
            else
                found = findPlayableUrl(child)
                if found <> "" then return found
            end if
        end for
    end if
    return ""
end function

function isDirectStream(value as String) as Boolean
    lower = LCase(value)
    if Left(lower, 7) <> "http://" and Left(lower, 8) <> "https://"
        return false
    end if
    return Instr(1, lower, ".m3u8") > 0 or Instr(1, lower, ".mp4") > 0 or Instr(1, lower, ".mpd") > 0
end function

function scalarText(value as Dynamic) as String
    if value = invalid then return ""
    if Type(value) = "String" then return value
    if Type(value) = "Integer" or Type(value) = "Float" or Type(value) = "LongInteger"
        return value.ToStr()
    end if
    return ""
end function
