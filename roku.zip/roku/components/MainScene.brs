sub init()
    m.categoryList = m.top.FindNode("categoryList")
    m.contentList = m.top.FindNode("contentList")
    m.statusLabel = m.top.FindNode("statusLabel")
    m.player = m.top.FindNode("player")
    ' Create the non-renderable Task dynamically so it is present in the
    ' SceneGraph before observers are attached.
    m.apiTask = CreateObject("roSGNode", "XuperApiTask")

    m.loggedIn = false
    m.session = invalid
    m.menuEntries = []
    m.contentEntries = []
    m.playlistItems = []
    m.pendingOperation = ""

    m.categoryList.ObserveField("itemSelected", "onCategorySelected")
    m.contentList.ObserveField("itemSelected", "onContentSelected")
    m.player.ObserveField("state", "onPlayerStateChanged")
    if m.apiTask <> invalid
        m.top.AppendChild(m.apiTask)
        m.apiTask.ObserveField("status", "onTaskStatusChanged")
        m.apiTask.ObserveField("result", "onTaskResult")
    end if

    setMenu([{title: "Iniciar sesión (opcional)", action: "login"}])
    setContentMessage("Cargando el catálogo como visitante...")
    m.categoryList.SetFocus(true)
    startGuestMode()
end sub

sub startGuestMode()
    if m.apiTask = invalid then return
    m.loggedIn = false
    m.statusLabel.text = "Cargando el catálogo como visitante..."
    m.apiTask.userId = ""
    m.apiTask.userToken = ""
    m.apiTask.portalCode = ""
    m.apiTask.sessionHost = ""
    m.pendingOperation = "guestHome"
    m.apiTask.operation = "guestHome"
    m.apiTask.control = "RUN"
end sub

sub setMenu(entries as Object)
    m.menuEntries = entries
    root = CreateObject("roSGNode", "ContentNode")
    for each entry in entries
        row = root.CreateChild("ContentNode")
        row.title = entry.title
    end for
    m.categoryList.content = root
end sub

sub setContentMessage(message as String)
    root = CreateObject("roSGNode", "ContentNode")
    row = root.CreateChild("ContentNode")
    row.title = message
    row.description = ""
    m.contentList.content = root
    m.contentEntries = []
end sub

sub onCategorySelected(event as Object)
    index = event.GetData()
    if index < 0 or index >= m.menuEntries.Count() then return
    entry = m.menuEntries[index]

    if entry.action = "login"
        if m.apiTask = invalid
            m.statusLabel.text = "No se pudo iniciar el servicio de acceso."
            return
        end if
        showUsernameDialog()
        return
    else if entry.action = "logout"
        clearSession()
        return
    else if entry.action = "guestHome"
        setContentMessage("Volviendo a solicitar el catálogo público...")
        startGuestMode()
        return
    else if entry.action = "playlist"
        showPlaylistGroup(entry.group)
        return
    else if entry.action = "shelf"
        m.statusLabel.text = "Solicitando " + entry.title + "..."
        setContentMessage("Conectando con el catálogo...")
        m.pendingOperation = "shelf"
        m.apiTask.operation = "shelf"
        m.apiTask.payload = FormatJson(entry.data)
        m.apiTask.control = "RUN"
        m.contentList.SetFocus(true)
        return
    else if entry.action = "notice"
        setContentMessage(entry.title)
        return
    end if
end sub

sub showUsernameDialog()
    dialog = CreateObject("roSGNode", "StandardKeyboardDialog")
    dialog.title = "Iniciar sesión"
    dialog.message = ["Escribe el correo o el teléfono con prefijo internacional."]
    dialog.keyboardDomain = "generic"
    dialog.buttons = ["Continuar", "Cancelar"]
    dialog.text = ""
    dialog.ObserveField("buttonSelected", "onUsernameSelected")
    m.top.dialog = dialog
end sub

sub onUsernameSelected(event as Object)
    dialog = m.top.dialog
    if dialog = invalid then return
    selected = event.GetData()
    entered = dialog.text
    m.top.dialog = invalid
    if selected <> 0 then return
    if entered = invalid
        m.statusLabel.text = "Escribe el correo o el teléfono con prefijo internacional."
        return
    end if
    if entered.Trim() = ""
        m.statusLabel.text = "Escribe el correo o el teléfono con prefijo internacional."
        return
    end if
    m.username = entered.Trim()
    showPasswordDialog()
end sub

sub showPasswordDialog()
    dialog = CreateObject("roSGNode", "StandardKeyboardDialog")
    dialog.title = "Contraseña"
    dialog.message = ["La contraseña se envía al servicio por HTTPS."]
    dialog.keyboardDomain = "password"
    dialog.textEditBox.secureMode = true
    dialog.textEditBox.secureLastCharacter = true
    dialog.buttons = ["Iniciar sesión", "Cancelar"]
    dialog.text = ""
    dialog.ObserveField("buttonSelected", "onPasswordSelected")
    m.top.dialog = dialog
end sub

sub onPasswordSelected(event as Object)
    dialog = m.top.dialog
    if dialog = invalid then return
    selected = event.GetData()
    entered = dialog.text
    m.top.dialog = invalid
    if selected <> 0 then return
    if entered = invalid
        m.statusLabel.text = "Escribe la contraseña de tu cuenta."
        return
    end if
    if entered = ""
        m.statusLabel.text = "Escribe la contraseña de tu cuenta."
        return
    end if

    deviceInfo = CreateObject("roDeviceInfo")
    m.apiTask.operation = "login"
    m.apiTask.username = m.username
    m.username = ""
    m.apiTask.password = entered
    m.apiTask.deviceId = deviceInfo.GetChannelClientId()
    m.apiTask.status = "Conectando..."
    m.pendingOperation = "login"
    setContentMessage("Conectando con el servicio de XuperTV...")
    m.statusLabel.text = "Intentando iniciar sesión..."
    m.apiTask.control = "RUN"
    m.categoryList.SetFocus(true)
end sub

sub onTaskStatusChanged(event as Object)
    status = event.GetData()
    if status <> invalid and status <> "" and m.pendingOperation <> ""
        m.statusLabel.text = status
    end if
end sub

sub onTaskResult(event as Object)
    raw = event.GetData()
    if raw = invalid or raw = ""
        m.pendingOperation = ""
        return
    end if
    result = ParseJson(raw)
    if result = invalid
        m.pendingOperation = ""
        m.statusLabel.text = "No se pudo interpretar la respuesta del servicio."
        setContentMessage("Vuelve a intentarlo.")
        return
    end if

    m.pendingOperation = ""
    operation = result.operation
    if operation = "login"
        handleLoginResult(result)
    else if operation = "guestHome"
        handleGuestHomeResult(result)
    else if operation = "shelf"
        handleShelfResult(result)
    else if operation = "play"
        handlePlayResult(result)
    end if
end sub

sub handleGuestHomeResult(result as Object)
    entries = [{title: "Iniciar sesión (opcional)", action: "login"}]
    if result.ok <> true
        entries.Push({title: "Reintentar catálogo", action: "guestHome"})
        setMenu(entries)
        m.statusLabel.text = result.message
        setContentMessage("No se pudo cargar el catálogo público. Puedes reintentar más tarde o iniciar sesión.")
        m.categoryList.SetFocus(true)
        return
    end if

    response = ParseJson(result.homeJson)
    if response = invalid
        entries.Push({title: "Reintentar catálogo", action: "guestHome"})
        setMenu(entries)
        m.statusLabel.text = "La respuesta del catálogo no contiene datos."
        setContentMessage("El servicio no publicó secciones para visitantes.")
        m.categoryList.SetFocus(true)
        return
    end if
    if response.data = invalid
        entries.Push({title: "Reintentar catálogo", action: "guestHome"})
        setMenu(entries)
        m.statusLabel.text = "La respuesta del catálogo no contiene datos."
        setContentMessage("El servicio no publicó secciones para visitantes.")
        m.categoryList.SetFocus(true)
        return
    end if

    recommendations = getField(response.data, "recommendList")
    if Type(recommendations) = "roArray"
        for each recommendation in recommendations
            title = valueText(getField(recommendation, "name"))
            if title = "" then title = valueText(getField(recommendation, "alias"))
            if title <> ""
                categoryId = getField(recommendation, "columnId")
                if categoryId = invalid then categoryId = 0
                categoryType = valueText(getField(recommendation, "type"))
                if categoryType = "" then categoryType = "0"
                entries.Push({
                    title: title
                    action: "shelf"
                    data: {columnId: categoryId, type: categoryType}
                })
            end if
        end for
    end if

    setMenu(entries)
    if entries.Count() = 1
        m.statusLabel.text = "El catálogo respondió, pero no publicó secciones para visitantes."
        setContentMessage("Inicia sesión solo si quieres usar las funciones de cuenta.")
    else
        m.statusLabel.text = "Catálogo de visitante cargado."
        setContentMessage("Explora el contenido sin iniciar sesión. El acceso a la cuenta es opcional.")
    end if
    m.categoryList.SetFocus(true)
end sub

sub handleLoginResult(result as Object)
    if result.ok <> true
        message = "No se pudo iniciar sesión."
        if result.message <> invalid and result.message <> ""
            message = result.message
        end if
        code = valueText(result.code)
        if code = "portal200001"
            message = "La versión de inicio de sesión está fuera de servicio. El catálogo de visitante puede seguir disponible."
        end if
        if code <> "" and Instr(1, message, code) = 0
            message = message + " (código " + code + ")"
        end if
        m.statusLabel.text = message
        setContentMessage("Respuesta del servicio: " + message)
        m.categoryList.SetFocus(true)
        return
    end if

    m.session = result.session
    if m.session = invalid
        m.statusLabel.text = "El servicio no devolvió una sesión utilizable."
        return
    end if
    if m.session.userId = invalid or m.session.userToken = invalid
        m.statusLabel.text = "El servicio no devolvió una sesión utilizable."
        return
    end if

    m.loggedIn = true
    m.apiTask.userId = m.session.userId
    m.apiTask.userToken = m.session.userToken
    m.apiTask.portalCode = m.session.portalCode
    m.apiTask.sessionHost = m.session.host
    m.playlistItems = parsePlaylist(result.playlistText)

    entries = [{title: "Cerrar sesión", action: "logout"}]
    home = invalid
    if result.homeJson <> invalid and result.homeJson <> ""
        home = ParseJson(result.homeJson)
    end if
    homeData = invalid
    if home <> invalid
        if home.data <> invalid
            homeData = home.data
        end if
    end if

    recommendations = invalid
    if homeData <> invalid
        recommendations = homeData.recommendList
    end if

    if Type(recommendations) = "roArray"
        for each recommendation in recommendations
            title = valueText(getField(recommendation, "name"))
            if title = ""
                title = valueText(getField(recommendation, "alias"))
            end if
            if title <> ""
                categoryId = getField(recommendation, "columnId")
                if categoryId = invalid then categoryId = 0
                categoryType = valueText(getField(recommendation, "type"))
                if categoryType = "" then categoryType = "0"
                categoryData = {columnId: categoryId, type: categoryType}
                entries.Push({
                    title: title
                    action: "shelf"
                    data: categoryData
                })
            end if
        end for
    end if

    if m.playlistItems.Count() > 0
        groups = []
        for each playlistItem in m.playlistItems
            groupName = playlistItem.group
            if groupName = "" then groupName = "TV en vivo"
            if not arrayHasText(groups, groupName)
                groups.Push(groupName)
            end if
        end for
        for each groupName in groups
            entries.Push({title: groupName, action: "playlist", group: groupName})
        end for
    end if

    if entries.Count() = 1
        entries.Push({title: "Catálogo", action: "notice"})
        m.statusLabel.text = "Sesión iniciada; el servicio no devolvió categorías compatibles."
        setContentMessage("La cuenta inició sesión, pero el catálogo no llegó en un formato que esta versión pueda mostrar.")
    else
        m.statusLabel.text = "Sesión iniciada. Elige una sección."
        setContentMessage("Conectado. Selecciona una sección para cargar contenido.")
    end if

    setMenu(entries)
    m.categoryList.SetFocus(true)
end sub

sub handleShelfResult(result as Object)
    if result.ok <> true
        message = "No se pudo cargar la sección."
        if result.message <> invalid and result.message <> ""
            message = result.message
        end if
        m.statusLabel.text = message
        setContentMessage("El servidor no devolvió contenido para esta sección.")
        m.categoryList.SetFocus(true)
        return
    end if
    response = ParseJson(result.responseJson)
    if response = invalid
        m.statusLabel.text = "La respuesta del catálogo no contiene datos."
        setContentMessage("No hay elementos para mostrar.")
        return
    end if
    if response.data = invalid
        message = "La respuesta del catálogo no contiene datos."
        if response.errorMessage <> invalid
            message = response.errorMessage
        end if
        m.statusLabel.text = message
        setContentMessage("No hay elementos para mostrar.")
        return
    end if

    data = response.data
    items = []
    columnId = 0
    columnType = "0"
    selectedIndex = m.categoryList.itemSelected
    if selectedIndex >= 0 and selectedIndex < m.menuEntries.Count()
        selected = m.menuEntries[selectedIndex]
        if selected.data <> invalid
            if selected.data.columnId <> invalid then columnId = selected.data.columnId
            if selected.data.type <> invalid then columnType = valueText(selected.data.type)
        end if
    end if

    channels = getField(data, "channelList")
    if Type(channels) = "roArray"
        for each channel in channels
            title = valueText(getField(channel, "name"))
            if title = "" then title = "Canal"
            description = valueText(getField(channel, "alias"))
            items.Push({
                title: title
                description: description
                itemKind: "live"
                channelCode: valueText(getField(channel, "channelCode"))
                contentId: ""
                columnId: columnId
                columnType: columnType
                url: ""
                streamformat: "hls"
            })
        end for
    end if

    assets = getField(data, "assetList")
    if Type(assets) = "roArray"
        for each asset in assets
            title = valueText(getField(asset, "name"))
            if title = "" then title = "Video"
            description = valueText(getField(asset, "description"))
            if description = "" then description = valueText(getField(asset, "viewpoint"))
            items.Push({
                title: title
                description: description
                itemKind: "vod"
                channelCode: ""
                contentId: valueText(getField(asset, "contentId"))
                columnId: columnId
                columnType: valueText(getField(asset, "type"))
                url: ""
                streamformat: "hls"
            })
        end for
    end if

    if items.Count() = 0
        message = "El servidor respondió, pero esta sección vino vacía."
        if response.errorMessage <> invalid and response.errorMessage <> ""
            message = response.errorMessage
        end if
        m.statusLabel.text = message
        setContentMessage("No hay contenido compatible para mostrar.")
        return
    end if

    showContentItems(items)
    m.statusLabel.text = "Catálogo recibido: " + items.Count().ToStr() + " elementos."
    m.contentList.SetFocus(true)
end sub

sub showPlaylistGroup(groupName as String)
    items = []
    for each playlistItem in m.playlistItems
        group = playlistItem.group
        if group = "" then group = "TV en vivo"
        if group = groupName
            items.Push({
                title: playlistItem.title
                description: groupName
                itemKind: "playlist"
                channelCode: ""
                contentId: ""
                columnId: 0
                columnType: ""
                url: playlistItem.url
                streamformat: playlistItem.streamformat
            })
        end if
    end for
    showContentItems(items)
    m.statusLabel.text = groupName + ": " + items.Count().ToStr() + " elementos."
    m.contentList.SetFocus(true)
end sub

sub showContentItems(items as Object)
    root = CreateObject("roSGNode", "ContentNode")
    m.contentEntries = items
    for each item in items
        row = root.CreateChild("ContentNode")
        row.title = item.title
        row.description = item.description
    end for
    m.contentList.content = root
end sub

sub onContentSelected(event as Object)
    index = event.GetData()
    if index < 0 or index >= m.contentEntries.Count() then return
    item = m.contentEntries[index]

    if item.url <> invalid and item.url <> ""
        startPlayback(item.url, item.title, item.streamformat)
        return
    end if

    m.statusLabel.text = "Solicitando reproducción de " + item.title + "..."
    m.pendingOperation = "play"
    m.apiTask.operation = "play"
    m.apiTask.payload = FormatJson(item)
    m.apiTask.control = "RUN"
end sub

sub handlePlayResult(result as Object)
    if result.ok = true and result.url <> invalid
        streamFormat = result.streamFormat
        startPlayback(result.url, "XuperTV", streamFormat)
    else
        message = "Roku no recibió una URL reproducible."
        if result.message <> invalid and result.message <> ""
            message = result.message
        end if
        m.statusLabel.text = message
        m.contentList.SetFocus(true)
    end if
end sub

sub startPlayback(url as String, title as String, streamFormat as String)
    videoContent = CreateObject("roSGNode", "ContentNode")
    videoContent.url = url
    videoContent.title = title
    if streamFormat <> invalid and streamFormat <> ""
        videoContent.streamformat = streamFormat
    else if Instr(1, LCase(url), ".m3u8") > 0
        videoContent.streamformat = "hls"
    else if Instr(1, LCase(url), ".mpd") > 0
        videoContent.streamformat = "dash"
    else if Instr(1, LCase(url), ".mp4") > 0
        videoContent.streamformat = "mp4"
    end if

    m.player.content = videoContent
    m.player.visible = true
    m.player.control = "play"
    m.player.SetFocus(true)
    m.statusLabel.text = "Reproduciendo."
end sub

sub onPlayerStateChanged(event as Object)
    state = event.GetData()
    if state = "finished" or state = "error"
        m.player.control = "stop"
        m.player.visible = false
        m.contentList.SetFocus(true)
        if state = "error"
            m.statusLabel.text = "Roku no pudo reproducir ese formato o el servicio exige otro protocolo."
        end if
    end if
end sub

sub clearSession()
    m.loggedIn = false
    m.session = invalid
    m.playlistItems = []
    m.apiTask.userId = ""
    m.apiTask.userToken = ""
    m.apiTask.portalCode = ""
    m.apiTask.sessionHost = ""
    setMenu([{title: "Iniciar sesión (opcional)", action: "login"}])
    setContentMessage("Sesión cerrada. Cargando el catálogo como visitante...")
    m.statusLabel.text = "Sesión cerrada."
    startGuestMode()
    m.categoryList.SetFocus(true)
end sub

function parsePlaylist(text as Dynamic) as Object
    items = []
    if text = invalid or Type(text) <> "String" or text = ""
        return items
    end if
    clean = text.Replace(Chr(13), "")
    lines = clean.Split(Chr(10))
    pendingTitle = ""
    pendingGroup = ""
    for each lineValue in lines
        line = lineValue.Trim()
        if Left(line, 8) = "#EXTINF:"
            comma = Instr(1, line, ",")
            if comma > 0
                pendingTitle = Mid(line, comma + 1).Trim()
            else
                pendingTitle = "Canal"
            end if
            pendingGroup = getQuotedAttribute(line, "group-title")
        else if Left(LCase(line), 7) = "http://" or Left(LCase(line), 8) = "https://"
            if pendingTitle <> ""
                streamFormat = "hls"
                lower = LCase(line)
                if Instr(1, lower, ".mp4") > 0 then streamFormat = "mp4"
                if Instr(1, lower, ".mpd") > 0 then streamFormat = "dash"
                items.Push({title: pendingTitle, group: pendingGroup, url: line, streamformat: streamFormat})
            end if
            pendingTitle = ""
            pendingGroup = ""
        end if
    end for
    return items
end function

function getQuotedAttribute(line as String, name as String) as String
    marker = name + "=" + Chr(34)
    startAt = Instr(1, line, marker)
    if startAt = 0 then return ""
    valueStart = startAt + Len(marker)
    endAt = Instr(valueStart, line, Chr(34))
    if endAt <= valueStart then return ""
    return Mid(line, valueStart, endAt - valueStart)
end function

function arrayHasText(values as Object, value as String) as Boolean
    for each current in values
        if current = value then return true
    end for
    return false
end function

function getField(value as Dynamic, key as String) as Dynamic
    if value = invalid or Type(value) <> "roAssociativeArray" then return invalid
    return value.Lookup(key)
end function

function valueText(value as Dynamic) as String
    if value = invalid then return ""
    if Type(value) = "String" then return value
    if Type(value) = "Integer" or Type(value) = "Float" or Type(value) = "LongInteger"
        return value.ToStr()
    end if
    return ""
end function

function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false

    if key = "back" and m.player.visible
        m.player.control = "stop"
        m.player.visible = false
        m.contentList.SetFocus(true)
        return true
    end if

    if key = "back" and m.contentList.HasFocus()
        m.categoryList.SetFocus(true)
        return true
    end if

    return false
end function
