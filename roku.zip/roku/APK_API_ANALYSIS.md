# Informe de análisis estático del APK

Archivo: `XuperTv-N0F4C3-v4.35.0-OFICIAL-ModByNF.apk`.

## Resumen del paquete

- APK Android versión 4.35.0; manifiesto: paquete `com.android.mgstxNF`, `minSdkVersion=19`, `targetSdkVersion=33`.
- La clase de aplicación y las pantallas iniciales siguen declaradas bajo `com.interactive.brasiliptv`; el APK se anuncia como XuperTV/ModByNF. La mezcla es consistente con una compilación modificada o reempaquetada, aunque no identifica por sí sola al operador.
- El APK es binario: contiene tres archivos DEX y bibliotecas nativas, no el proyecto Java/Kotlin original. Se desempaquetó sin ejecutar.
- El manifiesto declara TV Android (`LEANBACK_LAUNCHER`), permisos de red/almacenamiento y un servicio no exportado con permiso `BIND_VPN_SERVICE`. La declaración no demuestra que el servicio se active.
- Incluye `ijkplayer`/`ijkffmpeg` para reproducción Android. Esas bibliotecas no se pueden cargar en Roku.
- Incluye `assets/nf_ban.html`, una página de bloqueo que consulta `https://api.ipify.org` para mostrar la IP pública y enlaza a un grupo de Telegram. El DEX contiene una referencia a ese HTML; el análisis estático no determina cuándo se muestra.

Extracción completa: `apk_unpacked/` (2.374 entradas; 64.665.403 bytes descomprimidos).

## Cómo resuelve los servidores

Las llamadas de negocio usan la plantilla `{agreement}://{ip}/...`; el acuerdo (HTTP/HTTPS) y la IP se determinan durante la inicialización de dominios y el proceso SLB/GSLB. El inicio pasa por `WelcomeActivity` (`Init domain`) y almacena dominios principal/secundario. En el export de JADX se confirmó que hay valores iniciales de dominio en recursos, pero aparecen codificados en hexadecimal y la app los pasa por un helper de decodificación antes de usarlos.

El recorrido de arranque también aparece en el código decompilado: `WelcomeActivity.E6` lee `key_dcs_all_url` de las preferencias `cache.config`, puede usarlo para sustituir los dominios principal/secundario y luego inicia el resolvedor `.dcs`. `WelcomeActivity.D6` selecciona `key_tdc` y prepara datos de terminal como paquete, versión del sistema y MAC. El centro de configuración separa las entradas `key_portal`, `key_tdc`, `key_epg`, `key_dcs`, `key_ads` y otras. Por tanto, los dominios semilla están dentro del APK de forma ofuscada, mientras que la selección/configuración efectiva puede actualizarse durante el arranque. El uso de identificadores de terminal podría implicar validaciones del proveedor; el análisis no confirma si aceptaría un cliente Roku.

El asset `assets/domain_test.json` contiene únicamente `xx` en sus campos de dominio (`portal`, `epg`, `upgrade`, `market`, `notice`, `dccore`, `datacollect`, `ad`, etc.). En `res/values/strings.xml` aparecen recursos `portal_main`, `portal_backup`, `bigbee_main` y `bigbee_backup` con valores codificados; `ib.c` los decodifica mediante `jb.b.a()` cuando corresponde. No se copia aquí el resultado de decodificar dominios. Los objetos de respuesta incluyen direcciones/tokens SLB principal y de respaldo. No hay una lista de streams estática que conecte Roku directamente. La dirección local `192.168.1.10` aparece en un texto antiguo de activación/soporte, no como host de API.

La app trae una constante de manifiesto llamada `PORTAL_KEY` con un valor codificado. No se copia a este informe: es un dato interno de la compilación, no una dirección de API ni reemplaza el acceso autorizado al servicio.

## Rutas API encontradas

Encontré **92 rutas `/api/` distintas** en las anotaciones de la interfaz de red: 90 del servicio principal y 2 de anuncios. Además aparecen una ruta dinámica de EPG y tres plantillas de avisos. La interfaz está ofuscada (`Lsb/b;`), pero sus anotaciones permiten recuperar las rutas. La mayoría de métodos usan tres parámetros `String` y devuelven RxJava `Observable`; algunas llamadas EPG tienen más parámetros y una variante de reproducción VOD devuelve Retrofit `Call`. Los nombres de métodos están ofuscados, así que el nombre de la ruta es la etiqueta más clara.

### Configuración y servicios internos

- `/api/portalCore/config/get`
- `/api/portalCore/getBaseTime`
- `/api/portalCore/getPropertiesInfo`
- `/api/portalCore/v14/getSlbInfo`
- `/api/portalCore/v15/getSlbInfo`
- `/api/portalCore/v3/snToken`
- `/api/subs/terminal/metadata`

### Acceso, cuenta y dispositivos

- `/api/PreInstall/auth`
- `/api/portalCore/bindEmailGiftDays`
- `/api/portalCore/bindPhone`
- `/api/portalCore/changeBindPhone`
- `/api/portalCore/checkForceBind`
- `/api/portalCore/checkVerifiCode`
- `/api/portalCore/device-management/deleteDevice`
- `/api/portalCore/device-management/getDevice`
- `/api/portalCore/device/updateOrInsert`
- `/api/portalCore/emailResetPassNotice`
- `/api/portalCore/getAreaCode`
- `/api/portalCore/getEmailSuffix`
- `/api/portalCore/getVerifiCode`
- `/api/portalCore/pwdCheck`
- `/api/portalCore/qr/allowLogin`
- `/api/portalCore/qr/token`
- `/api/portalCore/register`
- `/api/portalCore/setPassword`
- `/api/portalCore/terminalAuth`
- `/api/portalCore/unBindEmail`
- `/api/portalCore/updateBindEmailOrPwd`
- `/api/portalCore/v2/bindEmail`
- `/api/portalCore/v2/changeBindEmail`
- `/api/portalCore/v2/sendEmailVerifyCode`
- `/api/portalCore/v2/validateVerifyCode`
- `/api/portalCore/v2/unBind`
- `/api/portalCore/v2/updateRestrictedStatus`
- `/api/portalCore/v4/resetPwd`
- `/api/portalCore/v5/heartbeat`
- `/api/portalCore/v5/loginOut`
- `/api/portalCore/v5/qr/getResult`
- `/api/portalCore/v8/active`
- `/api/portalCore/v8/login`
- `/api/portalCore/v9/getAuthInfo`

### Catálogo, personas y búsqueda

- `/api/portalCore/blSearchByContent`
- `/api/portalCore/blSearchByName`
- `/api/portalCore/delFavorite`
- `/api/portalCore/getFavorite`
- `/api/portalCore/getHome`
- `/api/portalCore/getItemByPerson`
- `/api/portalCore/getNextColumns`
- `/api/portalCore/getPerson`
- `/api/portalCore/getRecommendColumnContents`
- `/api/portalCore/searchResourceOrPerson`
- `/api/portalCore/v2/addFavorite`
- `/api/portalCore/v3/filterByContent`
- `/api/portalCore/v3/filterGenre`
- `/api/portalCore/v3/getColumnContents`
- `/api/portalCore/v3/getColumnRecommendResource`
- `/api/portalCore/v3/getProgram`
- `/api/portalCore/v3/getRecommends`
- `/api/portalCore/v3/getShelveData`
- `/api/portalCore/v3/searchByContent`
- `/api/portalCore/v3/searchByName`
- `/api/portalCore/v4/getItemData`

### Canales y reproducción

- `/api/portalCore/getAllbackProgram`
- `/api/portalCore/liveSearchByName`
- `/api/portalCore/v10/startPlayVOD`
- `/api/portalCore/v4/startPlayLive`
- `/api/portalCore/v6/getLiveData`
- `/api/portalCore/v6/startPlayBTV`

### EPG y deportes

- `/api/portalCore/epg/v2/getAllMatch`
- `/api/portalCore/epg/v2/getLineUps`
- `/api/portalCore/epg/v2/getMatchDetail`
- `/api/portalCore/epg/v2/getScoreboard`
- `/api/portalCore/epg/v2/getShelveMatch`
- `/api/portalCore/epg/v2/getTeamEvent`
- `/api/portalCore/epg/v3/getFootballMatch`
- `/api/portalCore/epg/v4/getNearestMatch`
- `/api/portalCore/epg/v5/getNearestMatch`

### Planes, compras y beneficios

- `/api/portalCore/addSubscribe`
- `/api/portalCore/apkQueryCoupon`
- `/api/portalCore/apkReceiveCoupon`
- `/api/portalCore/delSubscribe`
- `/api/portalCore/getExchangeOrderInfo`
- `/api/portalCore/getSubscribe`
- `/api/portalCore/package/getOrderInfo`
- `/api/portalCore/package/getPackageCustomization`
- `/api/portalCore/v2/getFree`
- `/api/portalCore/v2/getInviteCode`
- `/api/portalCore/v5/exchange`

### Ayuda y contacto

- `/api/portalCore/feedback/getCustomerService`
- `/api/portalCore/feedback/userFeedBack`

### Publicidad y telemetría

- `/api/adserver/report`
- `/api/adserver/v2/get_content`

### EPG dinámico y avisos

- `{protocol}://{ip}/epg/v2/live/app/utc{timezone}/{liveType}`
- `http://%s/notice/api/get_notice?pkg=%s&v=%s&language=en`
- `http://%s/notice/api/get_notice?pkg=%s&v=%s&sn=%s&userId=%s`
- `http://%s/notice/api/get_notice?pkg=%s&v=%s&sn=%s&userId=%s&language=`

### Observaciones sobre reproducción

- Los puntos de entrada del servidor son `/api/portalCore/v4/startPlayLive`, `/api/portalCore/v6/startPlayBTV` y `/api/portalCore/v10/startPlayVOD`. En el APK aparecen modelos de respuesta `StartPlayLiveResult`, `StartPlayBTVResult`, `StartPlayVODResult` y `GetPlayUrlResult`/`GetPlayUrlResultData`.
- No hay URL final `.m3u8` de canal/película integrada como catálogo estático. La URL se obtiene durante la sesión desde el backend. El APK también contiene `.m3u8` como formato, no como dirección de stream.
- La Roku puede volver a implementar la interfaz y usar su nodo `Video`, pero para equivalencia de servicio se necesitan el host bootstrap vigente, formato de solicitudes/respuestas, autenticación firmada y permiso de uso del proveedor. La lista de rutas sola no basta.

### Modelos de solicitud y respuesta visibles

- `LoginBean` contiene campos como `accountType`, `userName`, `password`, `signdata`, `macAddr`, `verificationCode` y `verificationToken`.
- `GetLiveDataBean` usa `columnId`, `dataVersion`, paginación, `portalCode`, `userId` y `userToken`; la respuesta `GetLiveDataResultData` incluye `channelList`, `dataVersion` y caducidad.
- `StartPlayLiveBean`, `StartPlayBTVBean` y `StartPlayVODBean` incluyen identificadores de canal/contenido, `portalCode`, `userId` y `userToken`. Las respuestas contienen `liveAddressList` o `episodeList`.
- `LoginResultData` expone datos de sesión como `userToken`, `verificationToken`, `portalCodeList` y `playlistUrl`. `GetSlbInfoBeanResultData` incluye listas CDN, parámetros de reproducción y ventanas de cambio de fuente.
- Estos nombres identifican formas de datos, pero no revelan por sí solos la serialización completa, las firmas ni la autorización del servicio.

## Qué implica para la adaptación Roku

La base Roku de `roku/` ya recrea la navegación general y tiene un nodo de video. Para conectar el backend de esta app habría que portar el bootstrap de dominios, la autorización de terminal, el inicio de sesión y los modelos de catálogo/reproducción. El APK contiene semillas de dominio ofuscadas, pero el proceso usa configuración dinámica y validación de terminal; el análisis no confirma que el servicio autorice a Roku. La alternativa compatible es usar una integración/API proporcionada por el operador o un catálogo que tengas permiso de reproducir.

## Alcance y límites de este análisis

El análisis del paquete combinó inspección estática, una lectura de la interfaz en el teléfono y revisión del Java aproximado exportado por JADX. No se capturó tráfico ni se contactó directamente a los servidores. El APK contiene bytecode compilado, ofuscado y bibliotecas nativas; JADX reconstruye código legible, pero no recupera el proyecto original. `domain_test.json` usa placeholders; aparte, hay semillas de dominio ofuscadas en recursos y valores efectivos que se resuelven/actualizan en runtime.

## Inspección visible de la app instalada

En una inspección posterior, con el teléfono conectado y la app abierta, el catálogo cargó sin solicitar credenciales. La pantalla de cuenta mostró que el correo y el teléfono se podían vincular para iniciar sesión y que la contraseña figuraba como no establecida. En `NF Config`, la opción para conservar el inicio de sesión estaba desactivada; también aparecían interruptores de VPN y de país sin restricciones, que se dejaron sin cambios. No se leyeron archivos privados, claves, contraseñas ni tokens del teléfono.

Esto confirma el comportamiento de inicio directo de esta compilación modificada, pero no proporciona una sesión portable ni el servidor de producción. La configuración efectiva se resuelve durante el arranque y la app la guarda en sus preferencias privadas; el valor no es legible en el APK ni se pudo leer por ADB normal en esta compilación no depurable. La pantalla visible tampoco documenta un cliente Roku. Para conectar el prototipo hace falta que el operador proporcione una integración autorizada: bootstrap de dominio, contrato de autenticación y catálogo/reproducción, y soporte para registrar un dispositivo Roku.

## Export de JADX

El usuario exportó el APK con JADX a `jadx_export/`; la carpeta contiene fuentes Java reconstruidas y recursos Android. La exportación confirma modelos de solicitud con datos de cuenta, metadatos de terminal y campos de firma, además de un flujo separado de autorización de terminal. El código Java reconstruido no equivale al proyecto fuente original y parte del código está ofuscado. No se copian claves ni valores de dominio decodificados en este informe.
